
from .hmd_record import hmd_record


class obval(hmd_record):    
    
   def output(self):
       return self.output_line()
       
       
       
